"""Overlapped UV validation, repair, selection, and UV Editor display."""

from dataclasses import dataclass, field
import re
import uuid

import bmesh
import bpy
import gpu
import numpy as np
from gpu_extras.batch import batch_for_shader

from . import _uv_overlay


# ---------------------------------------------------------------------------
# Validation


_BAKE_UDIM_MIN = 0.0
_BAKE_UDIM_MAX = 1.0
_BAKE_UDIM_AREA_EPSILON = 1e-12


def _clip_uv_polygon_to_bake_udim(uv_points):
    polygon = [
        (float(point[0]), float(point[1]))
        for point in uv_points
    ]

    def clip_to_boundary(points, axis, boundary, keep_greater):
        if not points:
            return []
        clipped = []
        previous = points[-1]
        previous_inside = (
            previous[axis] >= boundary
            if keep_greater
            else previous[axis] <= boundary
        )
        for current in points:
            current_inside = (
                current[axis] >= boundary
                if keep_greater
                else current[axis] <= boundary
            )
            if current_inside != previous_inside:
                axis_delta = current[axis] - previous[axis]
                if axis_delta != 0.0:
                    factor = (
                        (boundary - previous[axis]) / axis_delta
                    )
                    clipped.append((
                        previous[0]
                        + factor * (current[0] - previous[0]),
                        previous[1]
                        + factor * (current[1] - previous[1]),
                    ))
            if current_inside:
                clipped.append(current)
            previous = current
            previous_inside = current_inside
        return clipped

    for axis, boundary, keep_greater in (
        (0, _BAKE_UDIM_MIN, True),
        (0, _BAKE_UDIM_MAX, False),
        (1, _BAKE_UDIM_MIN, True),
        (1, _BAKE_UDIM_MAX, False),
    ):
        polygon = clip_to_boundary(
            polygon, axis, boundary, keep_greater
        )
    return polygon


def _uv_polygon_area(uv_points):
    if len(uv_points) < 3:
        return 0.0
    return abs(sum(
        first[0] * second[1] - second[0] * first[1]
        for first, second in zip(
            uv_points, uv_points[1:] + uv_points[:1]
        )
    )) * 0.5


def _triangle_intersects_bake_udim(uv_points):
    return (
        _uv_polygon_area(
            _clip_uv_polygon_to_bake_udim(uv_points)
        )
        > _BAKE_UDIM_AREA_EPSILON
    )


def _faces_intersecting_bake_udim(
    obj, uv_layer_name, face_indices
):
    if not face_indices:
        return set()
    bm = bmesh.from_edit_mesh(obj.data)
    bm.faces.ensure_lookup_table()
    uv_layer = bm.loops.layers.uv.get(uv_layer_name)
    if uv_layer is None:
        return set()

    matching_face_indices = set()
    for triangle in bm.calc_loop_triangles():
        face_index = triangle[0].face.index
        if face_index not in face_indices:
            continue
        if _triangle_intersects_bake_udim(
            [loop[uv_layer].uv for loop in triangle]
        ):
            matching_face_indices.add(face_index)
    return matching_face_indices


def _selected_edit_face_indices(obj):
    bm = bmesh.from_edit_mesh(obj.data)
    bm.faces.ensure_lookup_table()
    return {face.index for face in bm.faces if face.select}


def _uv_points_match(first, second, tolerance):
    return (first - second).length <= tolerance


def _expand_faces_to_uv_islands(
    obj, uv_layer_name, seed_face_indices, tolerance=1e-5
):
    """Grow the reported faces to the whole UV islands they belong to.

    Returns the islands one by one rather than a single set: an artist needs to
    hear "six shells are stacked", not "4494 faces are involved".
    """
    if not seed_face_indices:
        return []

    bm = bmesh.from_edit_mesh(obj.data)
    bm.faces.ensure_lookup_table()
    uv_layer = bm.loops.layers.uv.get(uv_layer_name)
    if uv_layer is None:
        return [set(seed_face_indices)]

    connected_faces = {face.index: set() for face in bm.faces}
    for edge in bm.edges:
        if len(edge.link_faces) != 2:
            continue
        first_face, second_face = edge.link_faces
        first_loop = next(
            loop for loop in first_face.loops if loop.edge == edge
        )
        second_loop = next(
            loop for loop in second_face.loops if loop.edge == edge
        )
        if (
            _uv_points_match(
                first_loop[uv_layer].uv,
                second_loop.link_loop_next[uv_layer].uv,
                tolerance,
            )
            and _uv_points_match(
                first_loop.link_loop_next[uv_layer].uv,
                second_loop[uv_layer].uv,
                tolerance,
            )
        ):
            connected_faces[first_face.index].add(second_face.index)
            connected_faces[second_face.index].add(first_face.index)

    islands = []
    visited = set()
    for seed_face_index in seed_face_indices:
        if seed_face_index in visited:
            continue
        island = {seed_face_index}
        visited.add(seed_face_index)
        pending_face_indices = [seed_face_index]
        while pending_face_indices:
            face_index = pending_face_indices.pop()
            for connected_face_index in connected_faces.get(face_index, ()):
                if connected_face_index not in visited:
                    visited.add(connected_face_index)
                    island.add(connected_face_index)
                    pending_face_indices.append(connected_face_index)
        islands.append(island)

    for face_index in visited:
        bm.faces[face_index].select = True
    bmesh.update_edit_mesh(
        obj.data, loop_triangles=False, destructive=False
    )
    return islands


def _uv_islands_from_faces(
    bm, uv_layer, face_indices, tolerance=1e-5
):
    bm.faces.ensure_lookup_table()
    candidate_indices = {
        face_index
        for face_index in face_indices
        if 0 <= face_index < len(bm.faces)
    }
    connected_faces = {
        face_index: set() for face_index in candidate_indices
    }

    for edge in bm.edges:
        if len(edge.link_faces) != 2:
            continue
        first_face, second_face = edge.link_faces
        if (
            first_face.index not in candidate_indices
            or second_face.index not in candidate_indices
        ):
            continue
        first_loop = next(
            loop for loop in first_face.loops if loop.edge == edge
        )
        second_loop = next(
            loop for loop in second_face.loops if loop.edge == edge
        )
        if (
            _uv_points_match(
                first_loop[uv_layer].uv,
                second_loop.link_loop_next[uv_layer].uv,
                tolerance,
            )
            and _uv_points_match(
                first_loop.link_loop_next[uv_layer].uv,
                second_loop[uv_layer].uv,
                tolerance,
            )
        ):
            connected_faces[first_face.index].add(second_face.index)
            connected_faces[second_face.index].add(first_face.index)

    islands = []
    unvisited = set(candidate_indices)
    while unvisited:
        seed = min(unvisited)
        island = {seed}
        pending = [seed]
        unvisited.remove(seed)
        while pending:
            face_index = pending.pop()
            for neighbour in connected_faces[face_index]:
                if neighbour not in unvisited:
                    continue
                unvisited.remove(neighbour)
                island.add(neighbour)
                pending.append(neighbour)
        islands.append(tuple(sorted(island)))
    return islands


def _native_overlap_issues(
    obj, uv_name_pattern, uv_map_required, expand_uv_islands=True,
    limit_to_bake_udim=True,
):
    context = bpy.context
    view_layer = context.view_layer
    previous_active_object = view_layer.objects.active
    previous_selected_objects = list(context.selected_objects)
    previous_mode = (
        previous_active_object.mode
        if previous_active_object
        else 'OBJECT'
    )
    previous_uv_sync = context.scene.tool_settings.use_uv_select_sync
    previous_uv_name = (
        obj.data.uv_layers.active.name
        if obj.data.uv_layers.active
        else ""
    )
    previous_edit_objects = ()
    previous_selection_states = {}
    if previous_mode == 'EDIT':
        previous_edit_objects = tuple(
            edit_object
            for edit_object in context.objects_in_mode_unique_data
            if edit_object.type == 'MESH'
        )
        previous_selection_states = {
            edit_object.name: _OverlapSelectionState.capture(
                edit_object
            )
            for edit_object in previous_edit_objects
        }

    issues = []
    matched_uv_map = False

    try:
        if (
            previous_active_object
            and previous_active_object.mode != 'OBJECT'
        ):
            bpy.ops.object.mode_set(mode='OBJECT')

        for selected_object in list(context.selected_objects):
            selected_object.select_set(False)
        obj.select_set(True)
        view_layer.objects.active = obj

        bpy.ops.object.mode_set(mode='EDIT')
        bpy.ops.mesh.select_mode(type='FACE')
        context.scene.tool_settings.use_uv_select_sync = True

        for uv_layer in obj.data.uv_layers:
            uv_layer_name = uv_layer.name
            if not uv_name_pattern.match(uv_layer_name):
                continue
            matched_uv_map = True
            obj.data.uv_layers.active = uv_layer
            bpy.ops.mesh.select_all(action='DESELECT')
            bpy.ops.uv.select_all(action='DESELECT')
            bpy.ops.uv.select_overlap(extend=False)
            overlap_face_indices = _selected_edit_face_indices(obj)
            if limit_to_bake_udim:
                overlap_face_indices = _faces_intersecting_bake_udim(
                    obj, uv_layer_name, overlap_face_indices
                )
            island_count = 0
            if expand_uv_islands:
                islands = _expand_faces_to_uv_islands(
                    obj, uv_layer_name, overlap_face_indices
                )
                island_count = len(islands)
                overlap_face_indices = set().union(*islands) if islands else set()
            sorted_face_indices = sorted(overlap_face_indices)
            if sorted_face_indices:
                where = " inside UDIM 1001" if limit_to_bake_udim else ""
                if island_count:
                    message = (
                        f"{island_count} UV island(s) overlap another"
                        f"{where} on UV set {uv_layer_name} "
                        f"({len(sorted_face_indices)} face(s))"
                    )
                else:
                    message = (
                        f"{len(sorted_face_indices)} face(s) with "
                        f"overlapping UVs{where} on UV set {uv_layer_name}"
                    )
                issues.append({
                    "message": message,
                    "element_ref": (
                        f"uv:{uv_layer_name};f:"
                        + ",".join(map(str, sorted_face_indices))
                    ),
                    "values": {
                        "uv": uv_layer_name,
                        "islands": island_count,
                        "faces": len(sorted_face_indices),
                        "udim_only": bool(limit_to_bake_udim),
                    },
                })

        bpy.ops.mesh.select_all(action='DESELECT')
    finally:
        try:
            context.scene.tool_settings.use_uv_select_sync = (
                previous_uv_sync
            )
            if obj.mode != 'OBJECT':
                bpy.ops.object.mode_set(mode='OBJECT')
            if (
                previous_uv_name
                and obj.data.uv_layers.get(previous_uv_name)
            ):
                obj.data.uv_layers.active = (
                    obj.data.uv_layers[previous_uv_name]
                )
            for selected_object in list(context.selected_objects):
                selected_object.select_set(False)
            for selected_object in previous_selected_objects:
                if selected_object.name in context.scene.objects:
                    selected_object.select_set(True)
            if (
                previous_active_object
                and previous_active_object.name in context.scene.objects
            ):
                view_layer.objects.active = previous_active_object
                if previous_mode != 'OBJECT':
                    bpy.ops.object.mode_set(mode=previous_mode)
                for edit_object in previous_edit_objects:
                    if (
                        edit_object.name in context.scene.objects
                        and edit_object.mode == 'EDIT'
                        and edit_object.name
                        in previous_selection_states
                    ):
                        _OverlapSelectionState.restore(
                            edit_object,
                            previous_selection_states[
                                edit_object.name
                            ],
                        )
        except Exception as error:
            print(
                "[Scene QC Validator] Overlapped UV selection "
                f"restore failed: {error}"
            )

    if not matched_uv_map and uv_map_required:
        issues.append({
            "message": (
                "No UV set matches regex "
                f"'{uv_name_pattern.pattern}'"
            ),
            "element_ref": "",
            "values": {"regex": uv_name_pattern.pattern,
                       "uvs": [uv.name for uv in obj.data.uv_layers]},
        })
    return issues


def check_uv_overlap(obj, item):
    if not obj.data.uv_layers:
        return []

    uv_name_expression = item.string_param_1 or ".+"
    try:
        uv_name_pattern = re.compile(uv_name_expression)
    except re.error as error:
        return [{
            "message": (
                f"Invalid UV set regex '{uv_name_expression}': {error}"
            ),
            "element_ref": "",
            "values": {"regex": uv_name_expression, "error": str(error)},
        }]

    try:
        return _native_overlap_issues(
            obj,
            uv_name_pattern,
            item.bool_param_1,
            expand_uv_islands=True,
            limit_to_bake_udim=item.bool_param_2,
        )
    except Exception as error:
        return [{
            "message": f"Native UV overlap check failed: {error}",
            "element_ref": "",
            "values": {"error": str(error)},
        }]


# ---------------------------------------------------------------------------
# UV Editor overlap display


_OVERLAP_VISUAL_COLOR = (
    0xF8 / 255.0,
    0xFC / 255.0,
    0x5A / 255.0,
    0xA6 / 255.0,
)
_OVERLAP_VISUAL_BUILD_DELAY = 0.08
_OVERLAP_VISUAL_MODAL_RETRY_DELAY = 0.05


@dataclass
class _OverlapVisualRuntime:
    enabled: bool = False
    targets: dict = field(default_factory=dict)
    # {object name: frozenset of material slot indices} while the review is
    # limited to one material; None while whole meshes are under review.
    material_slots: dict = None
    # Draw only what falls inside the bake tile, as the check's own
    # "Only UDIM 1001" says.
    limit_to_bake_udim: bool = True
    build_pending: bool = False
    building: bool = False
    depsgraph_handler_registered: bool = False
    load_handler_registered: bool = False
    generation: int = 0
    gizmos: dict = field(default_factory=dict)
    draw_handles: dict = field(default_factory=dict)

    def invalidate_pending_builds(self):
        self.generation += 1
        self.build_pending = False


_overlap_visual = _OverlapVisualRuntime()


def _report_overlap_visual_error(operation, error):
    print(
        "[Scene QC Validator] Overlapped UV visual "
        f"{operation} failed: {error}"
    )


@dataclass(frozen=True)
class _MeshSelectionSnapshot:
    uv_layer_name: str
    vert_indices: tuple
    edge_indices: tuple
    face_indices: tuple
    uv_loops: tuple


class _OverlapSelectionState:
    @staticmethod
    def capture(obj):
        bm = bmesh.from_edit_mesh(obj.data)
        bm.verts.ensure_lookup_table()
        bm.edges.ensure_lookup_table()
        bm.faces.ensure_lookup_table()
        uv_layer = bm.loops.layers.uv.active
        uv_loops = ()
        if uv_layer is not None:
            uv_loops = tuple(
                (
                    face.index,
                    loop_index,
                    loop.uv_select_vert,
                    loop.uv_select_edge,
                )
                for face in bm.faces
                for loop_index, loop in enumerate(face.loops)
                if loop.uv_select_vert or loop.uv_select_edge
            )
        return _MeshSelectionSnapshot(
            uv_layer.name if uv_layer is not None else "",
            tuple(vert.index for vert in bm.verts if vert.select),
            tuple(edge.index for edge in bm.edges if edge.select),
            tuple(face.index for face in bm.faces if face.select),
            uv_loops,
        )

    @staticmethod
    def restore(obj, snapshot):
        bm = bmesh.from_edit_mesh(obj.data)
        bm.verts.ensure_lookup_table()
        bm.edges.ensure_lookup_table()
        bm.faces.ensure_lookup_table()

        for vert in bm.verts:
            vert.select = False
        for edge in bm.edges:
            edge.select = False
        for face in bm.faces:
            face.select = False
        for vert_index in snapshot.vert_indices:
            if vert_index < len(bm.verts):
                bm.verts[vert_index].select = True
        for edge_index in snapshot.edge_indices:
            if edge_index < len(bm.edges):
                bm.edges[edge_index].select = True
        for face_index in snapshot.face_indices:
            if face_index < len(bm.faces):
                bm.faces[face_index].select = True

        uv_layer = bm.loops.layers.uv.get(snapshot.uv_layer_name)
        if uv_layer is not None:
            for face in bm.faces:
                for loop in face.loops:
                    loop.uv_select_vert = False
                    loop.uv_select_edge = False
            for (
                face_index,
                loop_index,
                select_vert,
                select_edge,
            ) in snapshot.uv_loops:
                if face_index >= len(bm.faces):
                    continue
                face = bm.faces[face_index]
                if loop_index >= len(face.loops):
                    continue
                loop = face.loops[loop_index]
                loop.uv_select_vert = select_vert
                loop.uv_select_edge = select_edge
        # All mesh and UV component flags come from the same captured state,
        # so flushing is unnecessary. More importantly, Blender's selection
        # flush expands UV vertex/edge flags to linked loops and would visibly
        # change the artist's UV selection after an overlap preview rebuild.


def _face_in_material_scope(face, slot_indices):
    """True when ``face`` belongs to the material a review is limited to.

    ``slot_indices`` is ``None`` for an unlimited (whole-mesh) review.
    """
    return slot_indices is None or face.material_index in slot_indices


def _object_slot_indices(material_slots, obj):
    """Slot indices in scope for ``obj``; ``None`` for a whole-mesh review.

    A mesh that is in Edit Mode without being part of a material review (another
    overlay may have opened it) has no slot in scope, so nothing of it counts.
    """
    if not material_slots:
        return None
    return material_slots.get(obj.name, frozenset())


class _NativeOverlapSelection:
    def __init__(self, context, objects, material_slots=None):
        self.objects = tuple(objects)
        self.material_slots = material_slots
        self.tool_settings = context.tool_settings
        self.uv_select_sync = (
            self.tool_settings.use_uv_select_sync
        )
        self.captured_selections = {
            obj.name: _OverlapSelectionState.capture(obj)
            for obj in self.objects
        }
        try:
            # The native overlap operator only sees UVs belonging to selected
            # mesh faces when UV selection sync is disabled. Make every visible
            # face in scope available only for the duration of this build;
            # restore() puts the artist's mesh and UV selections back
            # immediately afterwards. Faces outside the reviewed material stay
            # deselected so their islands are not measured against it - a
            # second material is a second texture set, free to sit anywhere.
            self.tool_settings.use_uv_select_sync = False
            for obj in self.objects:
                slot_indices = _object_slot_indices(
                    self.material_slots, obj
                )
                bm = bmesh.from_edit_mesh(obj.data)
                for vert in bm.verts:
                    vert.select = False
                for edge in bm.edges:
                    edge.select = False
                for face in bm.faces:
                    face.select = False
                for face in bm.faces:
                    if face.hide or not _face_in_material_scope(
                        face, slot_indices
                    ):
                        continue
                    face.select_set(True)
                bm.select_flush(True)
                bmesh.update_edit_mesh(
                    obj.data, loop_triangles=False, destructive=False
                )
            if bpy.ops.uv.select_all.poll():
                bpy.ops.uv.select_all(action='DESELECT')
            if bpy.ops.uv.select_overlap.poll():
                bpy.ops.uv.select_overlap(extend=False)
        except Exception:
            self.restore()
            raise

    def restore(self):
        if bpy.ops.uv.select_all.poll():
            bpy.ops.uv.select_all(action='DESELECT')
        for obj in self.objects:
            snapshot = self.captured_selections.get(obj.name)
            if snapshot is not None and obj.mode == 'EDIT':
                _OverlapSelectionState.restore(obj, snapshot)
        # Reassigning False after the native UV operator makes Blender run a
        # UV-selection synchronization pass even though the value is unchanged,
        # expanding the restored selection to linked UV loops. Only touch the
        # setting when it genuinely needs to change.
        if (
            self.tool_settings.use_uv_select_sync
            != self.uv_select_sync
        ):
            self.tool_settings.use_uv_select_sync = self.uv_select_sync


class SQC_GT_OverlapUVVisual(bpy.types.Gizmo):
    bl_idname = "SQC_GT_overlap_uv_visual"
    bl_target_properties = ()

    __slots__ = ("shapes", "build_requested")

    def setup(self):
        if not hasattr(self, "shapes"):
            self.shapes = []
            self.build_requested = True

    def draw(self, context):
        return

    def draw_select(self, context, select_id):
        self.draw_overlay(context)

    def test_select(self, context, location):
        return -1

    def request_build(self):
        self.build_requested = True

    def draw_overlay(self, context):
        if not _overlap_visual.enabled:
            return
        if self.build_requested:
            _schedule_overlap_visual_build(context, self)
            self.build_requested = False
        if not self.shapes:
            return
        _uv_overlay.draw_shapes(
            context, self.shapes, _OVERLAP_VISUAL_COLOR
        )


class SQC_GGT_OverlapUVVisual(bpy.types.GizmoGroup):
    bl_idname = "SQC_GGT_overlap_uv_visual"
    bl_label = "UV Overlap Overlay"
    bl_space_type = 'IMAGE_EDITOR'
    bl_region_type = 'WINDOW'
    bl_options = {'PERSISTENT', 'EXCLUDE_MODAL', 'SCALE'}

    @classmethod
    def poll(cls, context):
        return (
            _overlap_visual.enabled
            and context.mode == 'EDIT_MESH'
            and context.active_object is not None
            and context.active_object.type == 'MESH'
        )

    def setup(self, context):
        self.visual_gizmo = self.gizmos.new(
            "SQC_GT_overlap_uv_visual"
        )
        self.visual_gizmo.hide_select = True
        area_pointer = context.area.as_pointer()
        _overlap_visual.gizmos[area_pointer] = self.visual_gizmo

        draw_id = str(uuid.uuid4())
        _overlap_visual.draw_handles[draw_id] = (
            bpy.types.SpaceImageEditor.draw_handler_add(
                self._draw_post_pixel,
                (draw_id,),
                'WINDOW',
                'POST_PIXEL',
            )
        )

    def _draw_post_pixel(self, draw_id):
        try:
            context = bpy.context
            if self.poll(context):
                # When Texel Density is active in this UV Editor it owns the
                # combined draw pass and calls this gizmo after its own fill,
                # guaranteeing that overlaps stay on top without double-drawing.
                from ...operators import texel_density_visual
                texel_gizmo = texel_density_visual._review.gizmos.get(
                    context.area.as_pointer()
                )
                if (
                    texel_density_visual._review.active
                    and texel_gizmo is not None
                ):
                    return
                self.visual_gizmo.draw_overlay(context)
        except ReferenceError:
            draw_handle = _overlap_visual.draw_handles.pop(
                draw_id, None
            )
            if draw_handle is not None:
                bpy.types.SpaceImageEditor.draw_handler_remove(
                    draw_handle, 'WINDOW'
                )

    def refresh(self, context):
        pass


OVERLAP_VISUAL_CLASSES = (
    SQC_GT_OverlapUVVisual,
    SQC_GGT_OverlapUVVisual,
)


def is_overlap_visual_enabled():
    return _overlap_visual.enabled


def enable_overlap_visual(
    obj, uv_layer_name, material_slots=None, limit_to_bake_udim=True
):
    if not obj or obj.type != 'MESH':
        return False
    _overlap_visual.invalidate_pending_builds()
    _overlap_visual.enabled = True
    _overlap_visual.material_slots = material_slots
    _overlap_visual.limit_to_bake_udim = limit_to_bake_udim
    edit_objects = tuple(
        edit_object
        for edit_object in bpy.context.objects_in_mode_unique_data
        if (
            edit_object.type == 'MESH'
            and edit_object.mode == 'EDIT'
        )
    )
    if obj not in edit_objects:
        edit_objects = (obj,)
    _overlap_visual.targets = {
        edit_object.name: (
            edit_object.data.uv_layers.active.name
            if edit_object.data.uv_layers.active
            else ""
        )
        for edit_object in edit_objects
    }
    _overlap_visual.targets[obj.name] = uv_layer_name
    _ensure_overlap_visual_update_handler()
    _tag_uv_editor_redraw()
    _request_overlap_visual_rebuild()
    return True


def retarget_overlap_visual(uv_layer_names):
    """Point a running overlap review at another UV set."""
    if not _overlap_visual.enabled:
        return False
    _overlap_visual.invalidate_pending_builds()
    for object_name, uv_layer_name in uv_layer_names.items():
        if object_name in _overlap_visual.targets:
            _overlap_visual.targets[object_name] = uv_layer_name
    _request_overlap_visual_rebuild()
    _tag_uv_editor_redraw()
    return True


def rescope_overlap_visual(material_slots):
    """Point a running overlap review at another material's faces."""
    if not _overlap_visual.enabled:
        return False
    _overlap_visual.invalidate_pending_builds()
    _overlap_visual.material_slots = material_slots
    _request_overlap_visual_rebuild()
    _tag_uv_editor_redraw()
    return True


def _request_overlap_visual_rebuild():
    for area_pointer, visual_gizmo in list(
        _overlap_visual.gizmos.items()
    ):
        try:
            visual_gizmo.request_build()
        except ReferenceError:
            _overlap_visual.gizmos.pop(area_pointer, None)


def disable_overlap_visual():
    _overlap_visual.invalidate_pending_builds()
    _overlap_visual.enabled = False
    _overlap_visual.targets.clear()
    _overlap_visual.material_slots = None
    _overlap_visual.limit_to_bake_udim = True
    for area_pointer, visual_gizmo in list(
        _overlap_visual.gizmos.items()
    ):
        try:
            visual_gizmo.shapes.clear()
            visual_gizmo.build_requested = False
        except ReferenceError:
            _overlap_visual.gizmos.pop(area_pointer, None)
    _tag_uv_editor_redraw()


def _schedule_overlap_visual_build(context, visual_gizmo):
    if (
        _overlap_visual.build_pending
        or not _overlap_visual.enabled
    ):
        return

    _overlap_visual.build_pending = True
    build_generation = _overlap_visual.generation
    window = context.window
    area = context.area
    region = context.region

    def delayed_build():
        if build_generation != _overlap_visual.generation:
            return None
        if not _overlap_visual.enabled:
            _overlap_visual.build_pending = False
            return None
        if _uv_overlay.is_modal_operation_running(bpy.context):
            return _OVERLAP_VISUAL_MODAL_RETRY_DELAY
        _overlap_visual.build_pending = False
        try:
            with bpy.context.temp_override(
                window=window,
                area=area,
                region=region,
            ):
                _build_overlap_visual_batch(
                    bpy.context, visual_gizmo
                )
        except (ReferenceError, RuntimeError) as error:
            _report_overlap_visual_error("build", error)
        return None

    bpy.app.timers.register(
        delayed_build,
        first_interval=_OVERLAP_VISUAL_BUILD_DELAY,
    )


def _build_overlap_visual_batch(context, visual_gizmo):
    edit_objects = [
        obj
        for object_name in tuple(_overlap_visual.targets)
        if (
            (obj := context.scene.objects.get(object_name))
            is not None
            and obj.mode == 'EDIT'
        )
    ]
    if not edit_objects:
        visual_gizmo.shapes.clear()
        disable_overlap_visual()
        return

    _overlap_visual.building = True
    overlap_selection = None
    try:
        overlap_selection = _NativeOverlapSelection(
            context, edit_objects, _overlap_visual.material_slots
        )
        visual_gizmo.shapes.clear()
        for obj in edit_objects:
            slot_indices = _object_slot_indices(
                _overlap_visual.material_slots, obj
            )
            bm = bmesh.from_edit_mesh(obj.data)
            bm.faces.ensure_lookup_table()
            uv_layer = (
                bm.loops.layers.uv.get(
                    _overlap_visual.targets.get(obj.name, "")
                )
                or bm.loops.layers.uv.active
            )
            if not uv_layer:
                continue

            uv_coordinates = []
            for triangle in bm.calc_loop_triangles():
                if (
                    triangle[0].face.hide
                    or not triangle[0].face.select
                    or not _face_in_material_scope(
                        triangle[0].face, slot_indices
                    )
                    or (
                        not overlap_selection.uv_select_sync
                        and not all(
                            triangle_loop.uv_select_vert
                            for triangle_loop in triangle
                        )
                    )
                ):
                    continue
                polygon = [loop[uv_layer].uv for loop in triangle]
                if _overlap_visual.limit_to_bake_udim:
                    # Cutting the drawn shape at the square keeps the overlay
                    # on the bake tile. A project whose UV set is laid out
                    # beyond 0-1 needs to see the rest of it, so leave the
                    # triangle whole instead.
                    polygon = _clip_uv_polygon_to_bake_udim(polygon)
                if _uv_polygon_area(polygon) <= _BAKE_UDIM_AREA_EPSILON:
                    continue
                first_point = polygon[0]
                for point_index in range(1, len(polygon) - 1):
                    uv_coordinates.extend((
                        first_point,
                        polygon[point_index],
                        polygon[point_index + 1],
                    ))

            if uv_coordinates:
                unique_coordinates, triangle_indices = np.unique(
                    uv_coordinates,
                    return_inverse=True,
                    axis=0,
                )
                shader = gpu.shader.from_builtin('UNIFORM_COLOR')
                batch = batch_for_shader(
                    shader,
                    'TRIS',
                    {"pos": unique_coordinates.tolist()},
                    indices=triangle_indices.astype(np.int32),
                )
                batch.program_set(shader)
                visual_gizmo.shapes.append(
                    _uv_overlay.OverlayShape(batch, shader)
                )
    finally:
        if overlap_selection is not None:
            overlap_selection.restore()
        _overlap_visual.building = False
        _tag_uv_editor_redraw()


@bpy.app.handlers.persistent
def _overlap_visual_depsgraph_update(_scene, depsgraph):
    if (
        not _overlap_visual.enabled
        or _overlap_visual.building
    ):
        return

    edit_objects = [
        obj
        for object_name in tuple(_overlap_visual.targets)
        if (
            (obj := bpy.context.scene.objects.get(object_name))
            is not None
            and obj.mode == 'EDIT'
        )
    ]
    if not edit_objects:
        disable_overlap_visual()
        return
    target_meshes = {obj.data for obj in edit_objects}

    mesh_changed = any(
        isinstance(update.id, bpy.types.Mesh)
        and (
            update.id in target_meshes
            or getattr(update.id, "original", None)
            in target_meshes
        )
        and update.is_updated_geometry
        for update in depsgraph.updates
    )
    if not mesh_changed:
        return

    _request_overlap_visual_rebuild()
    _tag_uv_editor_redraw()


@bpy.app.handlers.persistent
def _overlap_visual_load_pre(_unused):
    disable_overlap_visual()
    _remove_overlap_visual_draw_handlers()
    _overlap_visual.gizmos.clear()


def _ensure_overlap_visual_update_handler():
    if not _overlap_visual.depsgraph_handler_registered:
        bpy.app.handlers.depsgraph_update_post.append(
            _overlap_visual_depsgraph_update
        )
        _overlap_visual.depsgraph_handler_registered = True
    if not _overlap_visual.load_handler_registered:
        bpy.app.handlers.load_pre.append(
            _overlap_visual_load_pre
        )
        _overlap_visual.load_handler_registered = True


def _tag_uv_editor_redraw():
    screen = getattr(bpy.context, "screen", None)
    if not screen:
        return
    for area in screen.areas:
        if area.type == 'IMAGE_EDITOR':
            area.tag_redraw()


def _remove_overlap_visual_draw_handlers():
    for draw_id, draw_handle in list(
        _overlap_visual.draw_handles.items()
    ):
        try:
            bpy.types.SpaceImageEditor.draw_handler_remove(
                draw_handle, 'WINDOW'
            )
        except (ReferenceError, ValueError):
            pass
        finally:
            _overlap_visual.draw_handles.pop(draw_id, None)


def unregister_overlap_visual():
    disable_overlap_visual()
    if (
        _overlap_visual.depsgraph_handler_registered
        and _overlap_visual_depsgraph_update
        in bpy.app.handlers.depsgraph_update_post
    ):
        bpy.app.handlers.depsgraph_update_post.remove(
            _overlap_visual_depsgraph_update
        )
    _overlap_visual.depsgraph_handler_registered = False
    if (
        _overlap_visual.load_handler_registered
        and _overlap_visual_load_pre
        in bpy.app.handlers.load_pre
    ):
        bpy.app.handlers.load_pre.remove(
            _overlap_visual_load_pre
        )
    _overlap_visual.load_handler_registered = False

    _remove_overlap_visual_draw_handlers()
    _overlap_visual.gizmos.clear()
