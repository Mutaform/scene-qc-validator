from ..common import *
from collections import defaultdict, deque
import re


def _uv_key(uv, tolerance):
    step = max(tolerance, 1e-9)
    return (round(uv.x / step), round(uv.y / step))


def _uv_edge_key(a, b, tolerance):
    key_a = _uv_key(a, tolerance)
    key_b = _uv_key(b, tolerance)
    return tuple(sorted((key_a, key_b)))


def _outside_uv_island_faces(obj, layer, tolerance, min_allowed, max_allowed):
    """Через bmesh, а не через obj.data: в режиме правки RNA-массив UV пуст, и
    проверка ругалась «канал не читается» на нормальной развёртке. Почему пуст -
    в checks/common._read_bmesh."""
    bm, should_free = _read_bmesh(obj)
    try:
        uv_layer = bm.loops.layers.uv.get(layer.name)
        if uv_layer is None:
            return set(), (0.0, 0.0, 0.0, 0.0)
        face_edges = {}
        edge_faces = defaultdict(list)
        outside_faces = set()
        min_u = min_v = float("inf")
        max_u = max_v = float("-inf")

        for face in bm.faces:
            loops = list(face.loops)
            edges = []
            face_is_outside = False
            for offset, loop in enumerate(loops):
                uv = loop[uv_layer].uv
                next_uv = loops[(offset + 1) % len(loops)][uv_layer].uv
                min_u = min(min_u, uv.x)
                min_v = min(min_v, uv.y)
                max_u = max(max_u, uv.x)
                max_v = max(max_v, uv.y)
                edges.append(_uv_edge_key(uv, next_uv, tolerance))
                if uv.x < min_allowed or uv.x > max_allowed or uv.y < min_allowed or uv.y > max_allowed:
                    face_is_outside = True
            face_edges[face.index] = edges
            for edge in edges:
                edge_faces[edge].append(face.index)
            if face_is_outside:
                outside_faces.add(face.index)
    finally:
        if should_free:
            bm.free()

    selected_faces = set()
    visited = set()
    for start_face in outside_faces:
        if start_face in visited:
            continue
        island = set()
        queue = deque([start_face])
        visited.add(start_face)
        while queue:
            face_index = queue.popleft()
            island.add(face_index)
            for edge in face_edges.get(face_index, []):
                for neighbor in edge_faces.get(edge, []):
                    if neighbor not in visited:
                        visited.add(neighbor)
                        queue.append(neighbor)
        selected_faces.update(island)

    return selected_faces, (min_u, min_v, max_u, max_v)


def check_single_uv_tile(obj, item):
    """Ensure the UV sets under review stay inside the first UDIM square.

    Which sets those are is a project rule, not a universal one: a lightmap or
    a detail channel may be laid out beyond 0-1 on purpose while the texture
    channels may not. The regex picks the sets to judge; the default ``.+``
    takes them all.
    """
    uv_layers = obj.data.uv_layers
    if not uv_layers:
        return []

    uv_name_expression = item.string_param_1 or ".+"
    try:
        uv_name_pattern = re.compile(uv_name_expression)
    except re.error as error:
        return [{
            "message": (
                f"Invalid UV set regex '{uv_name_expression}': {error}"
            ),
            "element_ref": "",
            "values": {"regex": uv_name_expression, "error": str(error)},
        }]

    tolerance = item.float_param_1 if item.float_param_1 > 0 else 0.001
    min_allowed = 0.0 - tolerance
    max_allowed = 1.0 + tolerance
    issues = []

    for layer in uv_layers:
        if not uv_name_pattern.match(layer.name):
            continue
        uv_data = layer.data
        if (not getattr(obj.data, "is_editmode", False)
                and len(uv_data) < len(obj.data.loops)):
            issues.append({
                "message": (
                    f"{layer.name} carries {len(uv_data)} UVs for "
                    f"{len(obj.data.loops)} loops and could not be read"
                ),
                "element_ref": f"uv:{layer.name}",
                "values": {"uv": layer.name, "uvs": len(uv_data),
                           "loops": len(obj.data.loops)},
            })
            continue

        shell_faces, bounds = _outside_uv_island_faces(obj, layer, tolerance, min_allowed, max_allowed)
        if shell_faces:
            face_indices = sorted(shell_faces)
            min_u, min_v, max_u, max_v = bounds
            bounds_text = f"U {min_u:.4f}..{max_u:.4f}, V {min_v:.4f}..{max_v:.4f}"
            issues.append({
                "message": f"{layer.name} has shells outside the square ({len(face_indices)} face(s), {bounds_text})",
                "element_ref": f"uv:{layer.name};f:" + ",".join(map(str, face_indices)),
                "values": {"uv": layer.name, "faces": len(face_indices),
                           "u": [round(min_u, 4), round(max_u, 4)],
                           "v": [round(min_v, 4), round(max_v, 4)]},
            })

    return issues
